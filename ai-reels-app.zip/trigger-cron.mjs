// Memicu pipeline AI Reels Daily di server Next.js lokal.
// Membaca CRON_SECRET dari .env.local (tidak pernah dicetak).
import { readFileSync } from "fs";
import { request } from "http";
import { spawn } from "child_process";

const ROOT = new URL(".", import.meta.url).pathname.replace(/\/$/, "");

function getSecret() {
  const env = readFileSync(`${ROOT}/.env.local`, "utf8");
  const m = env.match(/^CRON_SECRET=(.+)$/m);
  if (!m) throw new Error("CRON_SECRET tidak ditemukan di .env.local");
  return m[1].trim();
}

function serverUp() {
  return new Promise((resolve) => {
    const req = request({ host: "127.0.0.1", port: 3000, path: "/", method: "HEAD", timeout: 5000 }, (res) => {
      res.resume();
      resolve(true);
    });
    req.on("error", () => resolve(false));
    req.on("timeout", () => { req.destroy(); resolve(false); });
    req.end();
  });
}

async function ensureServer() {
  if (await serverUp()) return;
  console.log("Server belum jalan — menjalankan next start...");
  const child = spawn(`${ROOT}/node_modules/.bin/next`, ["start", "-p", "3000"], {
    cwd: ROOT, detached: true, stdio: "ignore",
  });
  child.unref();
  for (let i = 0; i < 24; i++) {
    await new Promise((r) => setTimeout(r, 2500));
    if (await serverUp()) { console.log("Server siap."); return; }
  }
  throw new Error("Server tidak bisa dijalankan.");
}

function triggerPipeline(secret) {
  return new Promise((resolve, reject) => {
    const req = request(
      { host: "127.0.0.1", port: 3000, path: `/api/cron/daily?secret=${encodeURIComponent(secret)}`, method: "GET", timeout: 120000 },
      (res) => {
        let body = "";
        res.on("data", (c) => (body += c));
        res.on("end", () => resolve({ status: res.statusCode, body: body.slice(0, 2000) }));
      }
    );
    req.on("error", reject);
    req.on("timeout", () => { req.destroy(); reject(new Error("Pipeline timeout")); });
    req.end();
  });
}

const secret = getSecret();
await ensureServer();
const out = await triggerPipeline(secret);
console.log("HTTP", out.status);
console.log(out.body);
