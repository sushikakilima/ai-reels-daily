// Daftar kunci env yang dibutuhkan aplikasi, dengan label Bahasa Indonesia.

export interface EnvKeyInfo {
  key: string;
  label: string;
  wajib: boolean;
}

export const ENV_KEYS: EnvKeyInfo[] = [
  { key: "TAVILY_API_KEY", label: "Kunci API Tavily (pencarian berita)", wajib: false },
  { key: "OPENAI_API_KEY", label: "Kunci API OpenAI (tulis konten & buat ilustrasi AI)", wajib: false },
  { key: "FB_APP_ID", label: "ID Aplikasi Facebook (login Instagram)", wajib: false },
  { key: "FB_APP_SECRET", label: "Rahasia Aplikasi Facebook (login Instagram)", wajib: false },
  { key: "IG_USER_ID", label: "ID Pengguna Instagram Bisnis (posting)", wajib: false },
  { key: "FB_PAGE_ACCESS_TOKEN", label: "Token Akses Halaman Facebook (posting)", wajib: false },
  { key: "NEXT_PUBLIC_SUPABASE_URL", label: "URL Supabase (basis data)", wajib: true },
  { key: "NEXT_PUBLIC_SUPABASE_ANON_KEY", label: "Kunci Anon Supabase (basis data)", wajib: true },
  { key: "CRON_SECRET", label: "Rahasia Cron (keamanan jadwal otomatis)", wajib: true },
];

export interface EnvStatus {
  key: string;
  label: string;
  wajib: boolean;
  ada: boolean;
}

export function getEnvStatus(): EnvStatus[] {
  return ENV_KEYS.map((k) => ({
    ...k,
    ada: !!process.env[k.key],
  }));
}

export function getMissingEnvKeys(): EnvStatus[] {
  return getEnvStatus().filter((s) => !s.ada);
}
