import { createClient, type SupabaseClient } from "@supabase/supabase-js";

// Lazy/guarded: module ini TIDAK PERNAH throw saat di-load.
// Saat env var kosong (mis. waktu build), pakai nilai dummy agar
// `npm run build` tetap lulus. Semua query dibungkus try/catch
// di route handler masing-masing.
//
// CATATAN ARSITEKTUR (2026-10-12):
// - Aplikasi ini HANYA memakai NEXT_PUBLIC_SUPABASE_URL +
//   NEXT_PUBLIC_SUPABASE_ANON_KEY untuk SEMUA akses Supabase
//   (baca dashboard, insert cron, upload storage).
// - SUPABASE_SERVICE_ROLE_KEY TIDAK tersedia (env "sensitive" di Vercel
//   bersifat write-only dan tidak bisa dibaca) — jangan referensikan
//   di mana pun.
// - ASUMSI RLS yang harus dikonfigurasi di dashboard Supabase:
//   1. Tabel ai_news: anon boleh SELECT semua baris.
//   2. Tabel ai_news: anon boleh INSERT baris baru.
//   3. Tabel ai_news: anon boleh UPDATE kolom `status`, dengan CHECK
//      constraint nilai hanya 'ready' | 'posted' | 'discarded'.
//   4. Storage bucket "reels-assets": anon boleh read publik
//      (public bucket) dan INSERT/upload objek baru.
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://dummy.supabase.co";
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "dummy-anon-key";

let cached: SupabaseClient | null = null;

export function getSupabase(): SupabaseClient {
  if (!cached) {
    cached = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: { persistSession: false },
    });
  }
  return cached;
}

export function isSupabaseConfigured(): boolean {
  return (
    !!process.env.NEXT_PUBLIC_SUPABASE_URL &&
    !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY &&
    process.env.NEXT_PUBLIC_SUPABASE_URL !== "https://dummy.supabase.co"
  );
}
