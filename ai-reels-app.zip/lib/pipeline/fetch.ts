import Parser from "rss-parser";

export interface FetchedNews {
  title: string;
  url: string;
  summary: string;
  publishedAt: string; // ISO
  source: string;
  imageUrl: string; // foto artikel dari RSS (bisa kosong)
}

interface RssFeed {
  url: string;
  source: string;
}

const RSS_FEEDS: RssFeed[] = [
  { url: "https://openai.com/blog/rss.xml", source: "OpenAI" },
  { url: "https://deepmind.google/blog/rss.xml", source: "DeepMind" },
  { url: "https://www.anthropic.com/news/rss.xml", source: "Anthropic" },
  { url: "https://blogs.microsoft.com/ai/feed/", source: "Microsoft AI" },
  { url: "https://ai.meta.com/blog/rss/", source: "Meta AI" },
  { url: "https://techcrunch.com/category/artificial-intelligence/feed/", source: "TechCrunch" },
  { url: "https://www.theverge.com/rss/index.xml", source: "The Verge" },
  { url: "https://venturebeat.com/category/ai/feed/", source: "VentureBeat" },
  { url: "https://www.technologyreview.com/feed/", source: "MIT Tech Review" },
];

const parser = new Parser({
  timeout: 15000,
  headers: { "User-Agent": "AI-Reels-Daily/1.0 (+news aggregator)" },
  customFields: {
    item: [["media:content", "mediaContent", { keepArray: false }]],
  },
});

// Ambil URL foto artikel dari enclosure atau media:content.
function extractImageUrl(item: Record<string, unknown>): string {
  try {
    const enc = item.enclosure as { url?: string } | undefined;
    if (enc?.url && /^https?:\/\//i.test(enc.url)) return enc.url.trim();
    const mc = item.mediaContent as { $?: { url?: string } } | undefined;
    const mcu = mc?.$?.url;
    if (mcu && /^https?:\/\//i.test(mcu)) return mcu.trim();
  } catch {
    // abaikan
  }
  return "";
}

async function fetchViaTavily(): Promise<FetchedNews[]> {
  const apiKey = process.env.TAVILY_API_KEY;
  if (!apiKey) return [];

  const res = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      api_key: apiKey,
      query: "AI news artificial intelligence",
      topic: "news",
      time_range: "day",
      max_results: 40,
      include_answer: false,
    }),
  });

  if (!res.ok) {
    throw new Error(`Tavily error: ${res.status}`);
  }

  const data = (await res.json()) as {
    results?: Array<{
      title?: string;
      url?: string;
      content?: string;
      published_date?: string;
    }>;
  };

  const cutoff = Date.now() - 24 * 60 * 60 * 1000;
  const items: FetchedNews[] = [];
  for (const r of data.results || []) {
    if (!r.title || !r.url) continue;
    const publishedAt = r.published_date
      ? new Date(r.published_date).toISOString()
      : new Date().toISOString();
    if (new Date(publishedAt).getTime() < cutoff) continue;
    items.push({
      title: r.title.trim(),
      url: r.url.trim(),
      summary: (r.content || "").trim().slice(0, 2000),
      publishedAt,
      source: "Tavily",
      imageUrl: "",
    });
  }
  return items;
}

async function fetchViaRss(): Promise<FetchedNews[]> {
  const cutoff = Date.now() - 24 * 60 * 60 * 1000;
  const items: FetchedNews[] = [];

  await Promise.all(
    RSS_FEEDS.map(async (feed) => {
      try {
        const parsed = await parser.parseURL(feed.url);
        for (const item of parsed.items || []) {
          try {
            const title = (item.title || "").trim();
            const url = (item.link || "").trim();
            if (!title || !url) continue;
            const dateRaw = item.isoDate || item.pubDate;
            const publishedAt = dateRaw
              ? new Date(dateRaw).toISOString()
              : new Date().toISOString();
            if (Number.isNaN(new Date(publishedAt).getTime())) continue;
            if (new Date(publishedAt).getTime() < cutoff) continue;
            const summary = (
              item.contentSnippet ||
              (item.content || "").replace(/<[^>]*>/g, " ")
            )
              .trim()
              .replace(/\s+/g, " ")
              .slice(0, 2000);
            const imageUrl = extractImageUrl(item as unknown as Record<string, unknown>);
            items.push({ title, url, summary, publishedAt, source: feed.source, imageUrl });
          } catch {
            // item rusak dilewati
          }
        }
      } catch {
        // satu feed mati tidak menggagalkan semua
      }
    })
  );

  return items;
}

// Fetch berita AI 24 jam terakhir.
// Prioritas: Tavily (jika ada key) → fallback RSS.
export async function fetchNewsLast24h(): Promise<FetchedNews[]> {
  try {
    const tavilyItems = await fetchViaTavily();
    if (tavilyItems.length > 0) return tavilyItems;
  } catch {
    // gagal → lanjut ke RSS
  }
  return fetchViaRss();
}
