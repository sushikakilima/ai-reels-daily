import type { FetchedNews } from "./fetch";
import { CATEGORIES, type NewsCategory } from "./categorize";

export interface GeneratedContent {
  indonesian_title: string;
  summary_points: [string, string, string];
  caption: string;
  category: NewsCategory;
}

const FIXED_HASHTAGS = "#AINews #BeritaAI #Teknologi #AIIndonesia #ArtificialIntelligence";

const SYSTEM_PROMPT = `Kamu adalah penulis konten Instagram Reels berbahasa Indonesia yang ahli menjelaskan berita teknologi AI kepada orang awam.

Tugas: dari sebuah berita AI berbahasa Inggris, hasilkan konten Bahasa Indonesia yang siap posting.

Aturan WAJIB:
1. Semua teks keluaran 100% Bahasa Indonesia. Jangan ada satu kata pun bahasa Inggris kecuali nama produk/perusahaan (mis. ChatGPT, OpenAI) dan hashtag.
2. Bahasa santai tapi informatif, mudah dipahami orang yang tidak paham teknologi.
3. Keluaran HARUS JSON valid dengan struktur persis:
{
  "indonesian_title": "judul berita dalam Bahasa Indonesia, maksimal 90 karakter",
  "summary_points": ["poin 1: fakta utama", "poin 2: dampaknya buat orang biasa", "poin 3: hal menarik lainnya"],
  "caption": "caption lengkap",
  "category": "salah satu dari: LLM | Text-to-Video | Image Generator | Regulasi AI | Startup AI | Tools AI | Riset Baru"
}
4. "caption" WAJIB mengikuti struktur ini persis:
   - Baris pertama: HOOK, satu kalimat mengejutkan/menarik perhatian.
   - Baris kosong, lalu "RINGKASAN:" diikuti 3 bullet (masing-masing diawali emoji yang relevan) berisi 3 summary_points.
   - Baris kosong, lalu "OPINI:" diikuti 1-2 kalimat opini/analisis singkat.
   - Baris kosong, lalu "Sumber Resmi: [nama sumber] - [url]"
   - Baris kosong, lalu hashtag: #AINews #BeritaAI #Teknologi #AIIndonesia #ArtificialIntelligence ditambah 3 hashtag relevan tambahan dalam Bahasa Indonesia/Inggris yang umum.
5. Jangan tambahkan teks di luar JSON.`;

function firstNSentences(text: string, n: number): string[] {
  const cleaned = text.replace(/\s+/g, " ").trim();
  if (!cleaned) return [];
  const sentences = cleaned.match(/[^.!?]+[.!?]+/g) || [cleaned];
  const result = sentences.map((s) => s.trim()).filter(Boolean).slice(0, n);
  while (result.length < n) result.push("...");
  return result.slice(0, n);
}

function buildFallbackCaption(
  item: FetchedNews,
  judulId: string,
  points: [string, string, string],
  extraHashtags: string
): string {
  return (
    `🤖 Kabar terbaru dari dunia AI: ${judulId}\n\n` +
    `RINGKASAN:\n` +
    `📌 ${points[0]}\n` +
    `📌 ${points[1]}\n` +
    `📌 ${points[2]}\n\n` +
    `OPINI: Perkembangan AI bergerak sangat cepat — pantau terus agar tidak ketinggalan.\n\n` +
    `Sumber Resmi: ${item.source} - ${item.url}\n\n` +
    `${FIXED_HASHTAGS} ${extraHashtags}`
  );
}

function extraHashtagsFor(category: NewsCategory): string {
  switch (category) {
    case "LLM":
      return "#ChatGPT #LLM #KecerdasanBuatan";
    case "Text-to-Video":
      return "#AIVideo #VideoAI #Sora";
    case "Image Generator":
      return "#AIArt #GambarAI #Midjourney";
    case "Regulasi AI":
      return "#RegulasiAI #EtikaAI #HukumTeknologi";
    case "Startup AI":
      return "#Startup #StartupIndonesia #TeknologiBisnis";
    case "Riset Baru":
      return "#RisetAI #Sains #Inovasi";
    case "Tools AI":
    default:
      return "#ToolsAI #Produktivitas #TipsAI";
  }
}

// Terjemahan Inggris → Indonesia via MyMemory (gratis, tanpa API key).
// Mengembalikan teks asli bila gagal, agar pipeline tidak berhenti.
async function translateToIndonesian(text: string): Promise<string> {
  const clean = text.replace(/\s+/g, " ").trim();
  if (!clean || clean === "...") return clean;
  // Bagi jadi kalimat; sisa teks tanpa tanda baca akhir JANGAN dibuang.
  const matched = clean.match(/[^.!?]+[.!?]+/g) || [];
  const consumed = matched.join("").length;
  const rest = clean.slice(consumed).trim();
  const sentences = [...matched];
  if (rest) sentences.push(rest);
  if (sentences.length === 0) sentences.push(clean);
  const chunks: string[] = [];
  let cur = "";
  for (const s of sentences) {
    if ((cur + s).length > 400 && cur) {
      chunks.push(cur.trim());
      cur = s;
    } else {
      cur += s;
    }
  }
  if (cur.trim()) chunks.push(cur.trim());

  const out: string[] = [];
  for (const ch of chunks) {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 10000);
      const res = await fetch(
        `https://api.mymemory.translated.net/get?q=${encodeURIComponent(
          ch
        )}&langpair=en|id`,
        { signal: ctrl.signal }
      );
      clearTimeout(timer);
      if (!res.ok) {
        out.push(ch);
        continue;
      }
      const data = (await res.json()) as {
        responseData?: { translatedText?: string };
      };
      let tr = data.responseData?.translatedText || ch;
      if (/MYMEMORY WARNING|QUERY LENGTH LIMIT|INVALID/i.test(tr)) tr = ch;
      // Guard: hasil terjemahan yang jauh lebih pendek dari aslinya mencurigakan → pakai teks asli.
      if (ch.length > 30 && tr.length < ch.length * 0.4) tr = ch;
      out.push(tr);
    } catch {
      out.push(ch);
    }
  }
  return out.join(" ");
}

// Fallback: ringkas + terjemahkan ke Bahasa Indonesia tanpa OpenAI.
async function buildTranslatedFallback(
  item: FetchedNews,
  category: NewsCategory
): Promise<GeneratedContent> {
  const [p1, p2, p3] = firstNSentences(item.summary || item.title, 3) as [
    string,
    string,
    string
  ];
  const [judulId, q1, q2, q3] = await Promise.all([
    translateToIndonesian(item.title),
    translateToIndonesian(p1),
    translateToIndonesian(p2),
    translateToIndonesian(p3),
  ]);
  const points: [string, string, string] = [q1, q2, q3];
  return {
    indonesian_title: judulId.slice(0, 140),
    summary_points: points,
    caption: buildFallbackCaption(item, judulId, points, extraHashtagsFor(category)),
    category,
  };
}

export async function generateContent(
  item: FetchedNews,
  category: NewsCategory
): Promise<GeneratedContent> {
  const apiKey = process.env.OPENAI_API_KEY;

  // ---- Fallback tanpa OpenAI: terjemahkan via MyMemory ----
  if (!apiKey) {
    return buildTranslatedFallback(item, category);
  }

  // ---- Dengan OpenAI ----
  try {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        temperature: 0.7,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          {
            role: "user",
            content: `Judul: ${item.title}\nSumber: ${item.source}\nURL: ${item.url}\nRingkasan: ${item.summary}\nTanggal: ${item.publishedAt}`,
          },
        ],
      }),
    });

    if (!res.ok) throw new Error(`OpenAI error: ${res.status}`);

    const data = (await res.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const raw = data.choices?.[0]?.message?.content || "";
    const parsed = JSON.parse(raw) as {
      indonesian_title?: string;
      summary_points?: string[];
      caption?: string;
      category?: string;
    };

    const cat = CATEGORIES.includes(parsed.category as NewsCategory)
      ? (parsed.category as NewsCategory)
      : category;

    const points = (parsed.summary_points || []).slice(0, 3);
    while (points.length < 3) points.push("...");
    const judulId = (parsed.indonesian_title || item.title).slice(0, 140);

    return {
      indonesian_title: judulId,
      summary_points: points as [string, string, string],
      caption: parsed.caption || buildFallbackCaption(item, judulId, points as [string, string, string], extraHashtagsFor(cat)),
      category: cat,
    };
  } catch {
    // gagal → fallback terjemahan
    return buildTranslatedFallback(item, category);
  }
}

export { CATEGORIES };
