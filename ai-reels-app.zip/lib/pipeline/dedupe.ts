import type { FetchedNews } from "./fetch";

// ---- Lapis 1: normalisasi URL ----
export function normalizeUrl(url: string): string {
  try {
    const u = new URL(url.trim());
    u.search = "";
    u.hash = "";
    let s = `${u.protocol}//${u.hostname.toLowerCase()}${u.pathname}`;
    if (s.endsWith("/") && s.length > 1) s = s.slice(0, -1);
    return s;
  } catch {
    return url.trim().toLowerCase().replace(/[?#].*$/, "").replace(/\/$/, "");
  }
}

const STOPWORDS = new Set([
  "the", "a", "an", "and", "or", "of", "to", "in", "on", "for", "with",
  "is", "are", "was", "were", "be", "by", "as", "at", "from", "that",
  "this", "it", "its", "new", "yang", "dan", "di", "ke", "dari", "untuk",
  "dengan", "pada", "adalah", "ini", "itu", "sebagai", "dalam", "akan",
  "tidak", "telah", "sudah", "lebih", "baru",
]);

function titleTokens(title: string): Set<string> {
  return new Set(
    title
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, " ")
      .split(/\s+/)
      .filter((t) => t.length > 2 && !STOPWORDS.has(t))
  );
}

function jaccardSimilarity(a: string, b: string): number {
  const ta = titleTokens(a);
  const tb = titleTokens(b);
  if (ta.size === 0 || tb.size === 0) return 0;
  let inter = 0;
  for (const t of ta) if (tb.has(t)) inter++;
  return inter / (ta.size + tb.size - inter);
}

function cosineSimilarity(a: number[], b: number[]): number {
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  if (na === 0 || nb === 0) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}

async function getEmbedding(text: string): Promise<number[] | null> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return null;
  try {
    const res = await fetch("https://api.openai.com/v1/embeddings", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "text-embedding-3-small",
        input: text.slice(0, 8000),
      }),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { data?: Array<{ embedding?: number[] }> };
    return data.data?.[0]?.embedding ?? null;
  } catch {
    return null;
  }
}

// ---- Dedupe 2 lapis ----
// Lapis 1: URL ternormalisasi.
// Lapis 2: kemiripan judul > 85% (embeddings jika ada key, else Jaccard).
export async function dedupeNews(items: FetchedNews[]): Promise<FetchedNews[]> {
  // Lapis 1: URL
  const seenUrls = new Set<string>();
  const afterUrl: FetchedNews[] = [];
  for (const item of items) {
    const norm = normalizeUrl(item.url);
    if (seenUrls.has(norm)) continue;
    seenUrls.add(norm);
    afterUrl.push(item);
  }

  // Lapis 2: kemiripan judul
  const useEmbeddings = !!process.env.OPENAI_API_KEY;
  const selected: FetchedNews[] = [];
  const selectedEmbeddings: (number[] | null)[] = [];

  for (const item of afterUrl) {
    let isDuplicate = false;

    if (useEmbeddings) {
      const emb = await getEmbedding(item.title);
      for (const prev of selectedEmbeddings) {
        if (emb && prev && cosineSimilarity(emb, prev) > 0.85) {
          isDuplicate = true;
          break;
        }
      }
      if (!isDuplicate) {
        selected.push(item);
        selectedEmbeddings.push(emb);
      }
    } else {
      for (const prev of selected) {
        if (jaccardSimilarity(item.title, prev.title) > 0.85) {
          isDuplicate = true;
          break;
        }
      }
      if (!isDuplicate) selected.push(item);
    }
  }

  return selected;
}
