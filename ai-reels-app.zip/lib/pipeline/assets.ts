import sharp from "sharp";
import { execFile } from "child_process";
import { promisify } from "util";
import { getSupabase } from "../supabase";

const execFileAsync = promisify(execFile);

const BUCKET = "reels-assets";
const W = 1080;
const H = 1920;

export interface BuiltAssets {
  illustrationUrl: string | null;
  videoUrl: string | null;
}

// Bungkus teks ke beberapa baris dengan lebar karakter maksimum.
function wrapText(text: string, maxChars: number): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let current = "";
  for (const word of words) {
    const next = current ? `${current} ${word}` : word;
    if (next.length > maxChars && current) {
      lines.push(current);
      current = word;
    } else {
      current = next;
    }
  }
  if (current) lines.push(current);
  return lines.slice(0, 8);
}

function escapeXml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Ilustrasi fallback: PNG 1080x1920 gradient sinematik + judul + label.
export async function buildFallbackIllustration(title: string): Promise<Buffer> {
  const lines = wrapText(title, 22);
  const fontSize = 64;
  const lineHeight = 82;
  const blockHeight = lines.length * lineHeight;
  const startY = H / 2 - blockHeight / 2 + fontSize;

  const textElements = lines
    .map(
      (line, i) =>
        `<text x="${W / 2}" y="${startY + i * lineHeight}" text-anchor="middle" ` +
        `font-family="sans-serif" font-size="${fontSize}" font-weight="bold" fill="#ffffff">${escapeXml(
          line
        )}</text>`
    )
    .join("\n");

  const svg = `
<svg width="${W}" height="${H}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#2e1065"/>
      <stop offset="45%" stop-color="#1e1b4b"/>
      <stop offset="75%" stop-color="#0c1a4b"/>
      <stop offset="100%" stop-color="#050508"/>
    </linearGradient>
    <radialGradient id="glow" cx="50%" cy="30%" r="60%">
      <stop offset="0%" stop-color="#7c3aed" stop-opacity="0.55"/>
      <stop offset="100%" stop-color="#7c3aed" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="${W}" height="${H}" fill="url(#bg)"/>
  <rect width="${W}" height="${H}" fill="url(#glow)"/>
  <rect x="60" y="60" width="220" height="64" rx="32" fill="none" stroke="#a78bfa" stroke-width="3"/>
  <text x="170" y="103" text-anchor="middle" font-family="sans-serif" font-size="30" font-weight="bold" fill="#c4b5fd" letter-spacing="4">AI REELS DAILY</text>
  ${textElements}
  <rect x="60" y="${H - 160}" width="${W - 120}" height="4" fill="#7c3aed" opacity="0.6"/>
  <text x="${W / 2}" y="${H - 100}" text-anchor="middle" font-family="sans-serif" font-size="28" fill="#94a3b8" letter-spacing="2">BERITA AI HARIAN • BAHASA INDONESIA</text>
</svg>`;

  return sharp(Buffer.from(svg)).png().toBuffer();
}

async function generateAiIllustration(title: string): Promise<Buffer | null> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return null;
  try {
    const res = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-image-1",
        prompt: `Ultra realistic cinematic 8k photorealistic photo, studio lighting, vertical 9:16 composition, tentang: ${title}. No text, no watermark.`,
        size: "1024x1536",
      }),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as {
      data?: Array<{ b64_json?: string; url?: string }>;
    };
    const first = data.data?.[0];
    if (first?.b64_json) {
      return Buffer.from(first.b64_json, "base64");
    }
    if (first?.url) {
      const imgRes = await fetch(first.url);
      if (!imgRes.ok) return null;
      return Buffer.from(await imgRes.arrayBuffer());
    }
    return null;
  } catch {
    return null;
  }
}

async function ffmpegAvailable(): Promise<boolean> {
  try {
    await execFileAsync("ffmpeg", ["-version"]);
    return true;
  } catch {
    return false;
  }
}

// Video Ken Burns 15 detik dari ilustrasi. Return null jika ffmpeg tidak ada/gagal.
async function buildKenBurnsVideo(image: Buffer): Promise<Buffer | null> {
  try {
    if (!(await ffmpegAvailable())) return null;
    const fs = await import("fs");
    const os = await import("os");
    const path = await import("path");
    const tmp = os.tmpdir();
    const inPath = path.join(tmp, `reels-in-${Date.now()}.png`);
    const outPath = path.join(tmp, `reels-out-${Date.now()}.mp4`);
    fs.writeFileSync(inPath, image);
    try {
      await execFileAsync("ffmpeg", [
        "-y",
        "-loop",
        "1",
        "-framerate",
        "30",
        "-i",
        inPath,
        "-vf",
        "scale=1080:1920,zoompan=z='min(zoom+0.0012,1.25)':d=450:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s=1080x1920:fps=30,format=yuv420p",
        "-t",
        "15",
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-crf",
        "23",
        "-pix_fmt",
        "yuv420p",
        "-movflags",
        "+faststart",
        outPath,
      ]);
      const video = fs.readFileSync(outPath);
      fs.unlinkSync(outPath);
      return video;
    } finally {
      try {
        fs.unlinkSync(inPath);
      } catch {
        // abaikan
      }
    }
  } catch {
    return null;
  }
}

async function ensureBucket(): Promise<void> {
  const supabase = getSupabase();
  try {
    await supabase.storage.createBucket(BUCKET, { public: true });
  } catch {
    // bucket mungkin sudah ada
  }
}

async function uploadToStorage(
  filename: string,
  buffer: Buffer,
  contentType: string
): Promise<string | null> {
  try {
    const supabase = getSupabase();
    await ensureBucket();
    const { error } = await supabase.storage
      .from(BUCKET)
      .upload(filename, buffer, { contentType, upsert: true });
    if (error) return null;
    const { data } = supabase.storage.from(BUCKET).getPublicUrl(filename);
    return data.publicUrl || null;
  } catch {
    return null;
  }
}

// Bangun ilustrasi + video untuk satu berita.
// `deadlineMs`: timestamp kapan budget waktu habis — jika AI image
// terlalu lama, langsung pakai fallback sharp.
export async function buildAssets(
  title: string,
  slug: string,
  deadlineMs: number
): Promise<BuiltAssets> {
  let image: Buffer | null = null;

  const timeLeft = deadlineMs - Date.now();
  if (process.env.OPENAI_API_KEY && timeLeft > 20000) {
    image = await generateAiIllustration(title);
  }
  if (!image) {
    image = await buildFallbackIllustration(title);
  }

  const illustrationUrl = await uploadToStorage(
    `${slug}.png`,
    image,
    "image/png"
  );

  let videoUrl: string | null = null;
  if (Date.now() < deadlineMs - 15000) {
    const video = await buildKenBurnsVideo(image);
    if (video) {
      videoUrl = await uploadToStorage(`${slug}.mp4`, video, "video/mp4");
    }
  }

  return { illustrationUrl, videoUrl };
}
