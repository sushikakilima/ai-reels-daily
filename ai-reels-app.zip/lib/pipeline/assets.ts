import sharp from "sharp";
import { execFile } from "child_process";
import { promisify } from "util";
import { getSupabase } from "../supabase";

const execFileAsync = promisify(execFile);

const BUCKET = "reels-assets";
const W = 1080;
const H = 1920;

export interface BuiltAssets {
  illustrationUrl: string | null;
  videoUrl: string | null;
  illustrationNote: string;
}

// Bungkus teks ke beberapa baris dengan lebar karakter maksimum.
function wrapText(text: string, maxChars: number): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let current = "";
  for (const word of words) {
    const next = current ? `${current} ${word}` : word;
    if (next.length > maxChars && current) {
      lines.push(current);
      current = word;
    } else {
      current = next;
    }
  }
  if (current) lines.push(current);
  return lines.slice(0, 8);
}

function escapeXml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Ilustrasi fallback: PNG 1080x1920 gradient sinematik + judul + label.
export async function buildFallbackIllustration(title: string): Promise<Buffer> {
  const lines = wrapText(title, 22);
  const fontSize = 64;
  const lineHeight = 82;
  const blockHeight = lines.length * lineHeight;
  const startY = H / 2 - blockHeight / 2 + fontSize;

  const textElements = lines
    .map(
      (line, i) =>
        `<text x="${W / 2}" y="${startY + i * lineHeight}" text-anchor="middle" ` +
        `font-family="sans-serif" font-size="${fontSize}" font-weight="bold" fill="#ffffff">${escapeXml(
          line
        )}</text>`
    )
    .join("\n");

  const svg = `
<svg width="${W}" height="${H}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#2e1065"/>
      <stop offset="45%" stop-color="#1e1b4b"/>
      <stop offset="75%" stop-color="#0c1a4b"/>
      <stop offset="100%" stop-color="#050508"/>
    </linearGradient>
    <radialGradient id="glow" cx="50%" cy="30%" r="60%">
      <stop offset="0%" stop-color="#7c3aed" stop-opacity="0.55"/>
      <stop offset="100%" stop-color="#7c3aed" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="${W}" height="${H}" fill="url(#bg)"/>
  <rect width="${W}" height="${H}" fill="url(#glow)"/>
  <rect x="60" y="60" width="220" height="64" rx="32" fill="none" stroke="#a78bfa" stroke-width="3"/>
  <text x="170" y="103" text-anchor="middle" font-family="sans-serif" font-size="30" font-weight="bold" fill="#c4b5fd" letter-spacing="4">AI REELS DAILY</text>
  ${textElements}
  <rect x="60" y="${H - 160}" width="${W - 120}" height="4" fill="#7c3aed" opacity="0.6"/>
  <text x="${W / 2}" y="${H - 100}" text-anchor="middle" font-family="sans-serif" font-size="28" fill="#94a3b8" letter-spacing="2">BERITA AI HARIAN • BAHASA INDONESIA</text>
</svg>`;

  return sharp(Buffer.from(svg)).png().toBuffer();
}

async function generateAiIllustration(title: string): Promise<Buffer | null> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return null;
  try {
    const res = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-image-1",
        prompt: `Ultra realistic cinematic 8k photorealistic photo, studio lighting, vertical 9:16 composition, tentang: ${title}. No text, no watermark.`,
        size: "1024x1536",
      }),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as {
      data?: Array<{ b64_json?: string; url?: string }>;
    };
    const first = data.data?.[0];
    if (first?.b64_json) {
      return Buffer.from(first.b64_json, "base64");
    }
    if (first?.url) {
      const imgRes = await fetch(first.url);
      if (!imgRes.ok) return null;
      return Buffer.from(await imgRes.arrayBuffer());
    }
    return null;
  } catch {
    return null;
  }
}

// Ambil og:image dari halaman artikel (cadangan bila RSS tidak menyertakan foto).
async function fetchOgImage(articleUrl: string): Promise<string> {
  try {
    if (!/^https?:\/\//i.test(articleUrl)) return "";
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 15000);
    let res: Response;
    try {
      res = await fetch(articleUrl, {
        signal: ctrl.signal,
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
        },
      });
    } finally {
      clearTimeout(timer);
    }
    if (!res.ok) return "";
    const ct = res.headers.get("content-type") || "";
    if (!ct.includes("text/html")) return "";
    const htmlText = await res.text();
    const m =
      htmlText.match(
        /<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i
      ) ||
      htmlText.match(
        /<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i
      );
    if (!m) return "";
    let u = m[1].replace(/&amp;/g, "&").trim();
    if (u.startsWith("//")) u = "https:" + u;
    if (!/^https?:\/\//i.test(u)) return "";
    return u;
  } catch {
    return "";
  }
}

// Unduh foto asli artikel (dari RSS). Return null bila gagal.
async function downloadArticleImage(imageUrl: string): Promise<Buffer | null> {
  try {
    if (!/^https?:\/\//i.test(imageUrl)) return null;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 25000);
    let res: Response;
    try {
      res = await fetch(imageUrl, {
        signal: ctrl.signal,
        headers: { "User-Agent": "AI-Reels-Daily/1.0 (+news aggregator)" },
      });
    } finally {
      clearTimeout(timer);
    }
    if (!res.ok) return null;
    const ct = res.headers.get("content-type") || "";
    if (!ct.startsWith("image/")) return null;
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length < 20000) return null;
    return await sharp(buf).resize(1080, 1920, { fit: "cover" }).png().toBuffer();
  } catch {
    return null;
  }
}

// Ilustrasi via Pollinations.ai (gratis, tanpa API key).
// Mengembalikan buffer gambar, atau pesan error agar tercatat di diagnostik.
type PollResult = { buffer: Buffer } | { error: string };

async function generatePollinationsIllustration(
  subject: string,
  timeLeftMs: number,
  attempt = 1
): Promise<PollResult> {
  const fail = async (reason: string): Promise<PollResult> => {
    // Satu kali percobaan ulang dengan jeda 5 detik.
    if (attempt === 1 && timeLeftMs > 120000) {
      await new Promise((r) => setTimeout(r, 5000));
      return generatePollinationsIllustration(subject, timeLeftMs - 5000, 2);
    }
    return { error: `percobaan ${attempt}: ${reason}` };
  };
  try {
    const prompt =
      `Ultra realistic cinematic photograph, 8k, photorealistic, dramatic studio lighting, ` +
      `vertical composition, subject: ${subject}. ` +
      `No text, no watermark, no cartoon, no illustration.`;
    const seed = Math.floor(Math.random() * 1000000);
    const url =
      `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}` +
      `?width=1080&height=1920&nologo=true&model=flux&seed=${seed}`;
    const ctrl = new AbortController();
    const budget = Math.min(90000, Math.max(25000, timeLeftMs - 10000));
    const timer = setTimeout(() => ctrl.abort(), budget);
    let res: Response;
    try {
      res = await fetch(url, { signal: ctrl.signal });
    } finally {
      clearTimeout(timer);
    }
    if (!res.ok) return fail(`HTTP ${res.status}`);
    const ct = res.headers.get("content-type") || "";
    if (!ct.startsWith("image/")) return fail(`content-type bukan gambar: ${ct}`);
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length < 20000)
      return fail(`ukuran gambar terlalu kecil: ${buf.length} bytes`);
    const normalized = await sharp(buf)
      .resize(1080, 1920, { fit: "cover" })
      .png()
      .toBuffer();
    return { buffer: normalized };
  } catch (e) {
    return fail(e instanceof Error ? e.message : String(e));
  }
}

async function ffmpegAvailable(): Promise<boolean> {
  try {
    await execFileAsync("ffmpeg", ["-version"]);
    return true;
  } catch {
    return false;
  }
}

// Video Ken Burns 15 detik dari ilustrasi. Return null jika ffmpeg tidak ada/gagal.
async function buildKenBurnsVideo(image: Buffer): Promise<Buffer | null> {
  try {
    if (!(await ffmpegAvailable())) return null;
    const fs = await import("fs");
    const os = await import("os");
    const path = await import("path");
    const tmp = os.tmpdir();
    const inPath = path.join(tmp, `reels-in-${Date.now()}.png`);
    const outPath = path.join(tmp, `reels-out-${Date.now()}.mp4`);
    fs.writeFileSync(inPath, image);
    try {
      await execFileAsync("ffmpeg", [
        "-y",
        "-loop",
        "1",
        "-framerate",
        "30",
        "-i",
        inPath,
        "-vf",
        "scale=1080:1920,zoompan=z='min(zoom+0.0012,1.25)':d=450:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s=1080x1920:fps=30,format=yuv420p",
        "-t",
        "15",
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-crf",
        "23",
        "-pix_fmt",
        "yuv420p",
        "-movflags",
        "+faststart",
        outPath,
      ]);
      const video = fs.readFileSync(outPath);
      fs.unlinkSync(outPath);
      return video;
    } finally {
      try {
        fs.unlinkSync(inPath);
      } catch {
        // abaikan
      }
    }
  } catch {
    return null;
  }
}

async function ensureBucket(): Promise<void> {
  const supabase = getSupabase();
  try {
    await supabase.storage.createBucket(BUCKET, { public: true });
  } catch {
    // bucket mungkin sudah ada
  }
}

async function uploadToStorage(
  filename: string,
  buffer: Buffer,
  contentType: string
): Promise<string | null> {
  try {
    const supabase = getSupabase();
    await ensureBucket();
    const { error } = await supabase.storage
      .from(BUCKET)
      .upload(filename, buffer, { contentType, upsert: true });
    if (error) return null;
    const { data } = supabase.storage.from(BUCKET).getPublicUrl(filename);
    return data.publicUrl || null;
  } catch {
    return null;
  }
}

// Bangun ilustrasi + video untuk satu berita.
// Urutan: foto artikel (RSS / og:image) → ilustrasi AI (OpenAI bila ada key, else Pollinations gratis) → gradient.
// `deadlineMs`: timestamp kapan budget waktu habis.
export async function buildAssets(
  title: string,
  slug: string,
  deadlineMs: number,
  articleImageUrl?: string,
  articleUrl?: string
): Promise<BuiltAssets> {
  let image: Buffer | null = null;
  let illustrationNote = "gradient-fallback";

  // 1. Foto asli artikel — paling relevan untuk berita.
  let imgUrl = articleImageUrl || "";
  if (!imgUrl && articleUrl && deadlineMs - Date.now() > 120000) {
    imgUrl = await fetchOgImage(articleUrl);
  }
  if (imgUrl && deadlineMs - Date.now() > 30000) {
    image = await downloadArticleImage(imgUrl);
    if (image) illustrationNote = "foto-artikel";
  }

  // 2. Ilustrasi AI.
  if (!image) {
    const t2 = deadlineMs - Date.now();
    if (process.env.OPENAI_API_KEY && t2 > 20000) {
      image = await generateAiIllustration(title);
      if (image) illustrationNote = "openai";
    } else if (!process.env.OPENAI_API_KEY && t2 > 100000) {
      const r = await generatePollinationsIllustration(title, t2);
      if ("buffer" in r) {
        image = r.buffer;
        illustrationNote = "pollinations-ai";
      } else {
        illustrationNote = `pollinations-gagal: ${r.error}`;
      }
    }
  }

  if (!image) {
    image = await buildFallbackIllustration(title);
  }

  const illustrationUrl = await uploadToStorage(
    `${slug}.png`,
    image,
    "image/png"
  );

  let videoUrl: string | null = null;
  if (Date.now() < deadlineMs - 15000) {
    const video = await buildKenBurnsVideo(image);
    if (video) {
      videoUrl = await uploadToStorage(`${slug}.mp4`, video, "video/mp4");
    }
  }

  return { illustrationUrl, videoUrl, illustrationNote };
}
