export type NewsCategory =
  | "LLM"
  | "Text-to-Video"
  | "Image Generator"
  | "Regulasi AI"
  | "Startup AI"
  | "Tools AI"
  | "Riset Baru";

export const CATEGORIES: NewsCategory[] = [
  "LLM",
  "Text-to-Video",
  "Image Generator",
  "Regulasi AI",
  "Startup AI",
  "Tools AI",
  "Riset Baru",
];

// Peta keyword (huruf kecil) → kategori. Dicek berurutan; yang pertama cocok menang.
const KEYWORD_MAP: Array<{ category: NewsCategory; keywords: string[] }> = [
  {
    category: "Regulasi AI",
    keywords: [
      "regulation", "regulator", "regulasi", "eu ai act", "ai act",
      "copyright", "hak cipta", "lawsuit", "gugatan", "senate", "congress",
      "parliament", "policy", "kebijakan", "ban", "pelarangan", "dilarang",
      "safety institute", "alignment", "misuse", "deepfake law",
    ],
  },
  {
    category: "Text-to-Video",
    keywords: [
      "text-to-video", "video generation", "video generator", "sora",
      "veo", "runway", "pika", "kling", "text to video", "generative video",
      "video ai", "ai video",
    ],
  },
  {
    category: "Image Generator",
    keywords: [
      "image generation", "image generator", "text-to-image", "dall-e",
      "dalle", "midjourney", "stable diffusion", "imagen", "flux",
      "generative image", "ai image", "gambar ai", "image model",
    ],
  },
  {
    category: "Startup AI",
    keywords: [
      "startup", "funding", "raises", "series a", "series b", "series c",
      "seed round", "pendanaan", "unicorn", "valuation", "valuasi",
      "acqui", "merger", "ipo",
    ],
  },
  {
    category: "Riset Baru",
    keywords: [
      "research", "riset", "paper", "arxiv", "study", "studi", "benchmark",
      "breakthrough", "terobosan", "scientist", "peneliti", "university",
      "universitas", "lab ",
    ],
  },
  {
    category: "Tools AI",
    keywords: [
      "tool", "tools", "app ", "launch", "luncur", "release", "update",
      "feature", "fitur", "plugin", "extension", "copilot", "assistant",
      "chatbot", "agent", "agen", "workflow", "productivity", "api ",
    ],
  },
  {
    category: "LLM",
    keywords: [
      "llm", "large language model", "gpt", "claude", "gemini", "llama",
      "mistral", "chatgpt", "copilot", "model bahasa", "language model",
      "reasoning model", "openai", "anthropic", "deepseek", "qwen",
      "token", "context window", "prompt",
    ],
  },
];

export function categorizeNews(title: string, summary: string): NewsCategory {
  const text = `${title} ${summary}`.toLowerCase();
  for (const { category, keywords } of KEYWORD_MAP) {
    for (const kw of keywords) {
      if (text.includes(kw)) return category;
    }
  }
  return "Tools AI"; // default
}

// Pilih hingga `limit` item dengan variasi kategori:
// usahakan tiap kategori terwakili, maksimal `maxPerCategory` per kategori.
export function selectWithCategoryVariety<T extends { category?: NewsCategory }>(
  items: T[],
  limit = 10,
  maxPerCategory = 3
): T[] {
  const selected: T[] = [];
  const counts = new Map<NewsCategory, number>();

  for (const cat of CATEGORIES) {
    if (selected.length >= limit) break;
    for (const item of items) {
      if (selected.length >= limit) break;
      if (selected.includes(item)) continue;
      if (item.category !== cat) continue;
      const c = counts.get(cat) || 0;
      if (c >= maxPerCategory) continue;
      counts.set(cat, c + 1);
      selected.push(item);
    }
  }

  // Isi sisa slot dengan item apa pun yang belum dipilih.
  for (const item of items) {
    if (selected.length >= limit) break;
    if (selected.includes(item)) continue;
    selected.push(item);
  }

  return selected.slice(0, limit);
}
