"use client";

import { useState } from "react";

export interface NewsItem {
  id: string;
  original_title: string;
  indonesian_title: string;
  original_url: string;
  summary_id: string;
  caption_id: string;
  illustration_url: string | null;
  reels_video_url: string | null;
  category: string;
  published_at: string;
  status: "ready" | "posted";
  source_name?: string;
}

function formatTanggal(iso: string): string {
  try {
    return new Intl.DateTimeFormat("id-ID", {
      day: "numeric",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "Asia/Jakarta",
    }).format(new Date(iso));
  } catch {
    return iso;
  }
}

function sourceName(item: NewsItem): string {
  try {
    return new URL(item.original_url).hostname.replace(/^www\./, "");
  } catch {
    return "Sumber";
  }
}

export default function NewsCard({
  item,
  onHilang,
}: {
  item: NewsItem;
  onHilang: (id: string) => void;
}) {
  const [toast, setToast] = useState<string | null>(null);
  const [toastError, setToastError] = useState(false);
  const [posting, setPosting] = useState(false);
  const [membuang, setMembuang] = useState(false);
  const [terposting, setTerposting] = useState(item.status === "posted");

  function tampilToast(pesan: string, error = false) {
    setToast(pesan);
    setToastError(error);
    setTimeout(() => setToast(null), 4000);
  }

  async function handlePosting() {
    if (posting || terposting) return;
    setPosting(true);
    try {
      const res = await fetch(`/api/news/${item.id}/publish`, { method: "POST" });
      const data = await res.json();
      if (res.ok && data.sukses) {
        setTerposting(true);
        tampilToast("✅ Berhasil diposting ke Instagram!");
      } else if (data.connectUrl) {
        tampilToast(`⚠️ ${data.error || "Hubungkan akun Instagram dulu"}. Buka halaman Hubungkan Instagram.`, true);
      } else {
        tampilToast(`❌ Gagal posting: ${data.error || "kesalahan tak dikenal"}`, true);
      }
    } catch {
      tampilToast("❌ Gagal posting: jaringan bermasalah.", true);
    } finally {
      setPosting(false);
    }
  }

  async function handleBuang() {
    if (membuang) return;
    if (!confirm("Buang berita ini? Berita tidak akan muncul lagi di dashboard.")) return;
    setMembuang(true);
    try {
      const res = await fetch(`/api/news/${item.id}/discard`, { method: "POST" });
      const data = await res.json();
      if (res.ok && data.sukses) {
        onHilang(item.id);
      } else {
        tampilToast(`❌ Gagal membuang: ${data.error || "coba lagi"}`, true);
      }
    } catch {
      tampilToast("❌ Gagal membuang: jaringan bermasalah.", true);
    } finally {
      setMembuang(false);
    }
  }

  return (
    <article className="card-enter flex flex-col overflow-hidden rounded-2xl bg-card ring-1 ring-white/10 transition hover:ring-violet-500/50">
      {/* Preview 9:16 */}
      <div className="relative aspect-[9/16] w-full overflow-hidden bg-black">
        {item.reels_video_url ? (
          <video
            src={item.reels_video_url}
            className="h-full w-full object-cover"
            autoPlay
            muted
            loop
            playsInline
          />
        ) : item.illustration_url ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={item.illustration_url}
            alt={item.indonesian_title}
            className="h-full w-full object-cover"
            loading="lazy"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-violet-900 to-blue-950">
            <span className="text-5xl">🤖</span>
          </div>
        )}

        {/* Badge status */}
        <span
          className={`absolute left-3 top-3 rounded-full px-3 py-1 text-xs font-bold ${
            terposting
              ? "bg-blue-600 text-white"
              : "bg-green-600 text-white"
          }`}
        >
          {terposting ? "Terposting" : "Siap"}
        </span>
        {/* Badge kategori */}
        <span className="absolute right-3 top-3 rounded-full bg-black/70 px-3 py-1 text-xs font-semibold text-violet-300 ring-1 ring-violet-500/40">
          {item.category}
        </span>
      </div>

      {/* Isi kartu */}
      <div className="flex flex-1 flex-col gap-3 p-4">
        <h3 className="line-clamp-3 text-sm font-bold leading-snug text-slate-100">
          {item.indonesian_title}
        </h3>

        <details className="caption-box rounded-xl bg-card2 p-3 text-xs text-slate-300">
          <summary className="font-semibold text-violet-300">
            Lihat caption
          </summary>
          <p className="mt-2 whitespace-pre-wrap leading-relaxed">
            {item.caption_id}
          </p>
        </details>

        <div className="mt-auto flex flex-col gap-1 text-xs text-slate-400">
          <a
            href={item.original_url}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sky-400 hover:underline"
          >
            Sumber Resmi: {sourceName(item)}
          </a>
          <span>🗓️ {formatTanggal(item.published_at)} WIB</span>
        </div>

        {/* Dua tombol besar */}
        <div className="flex flex-col gap-2 pt-1">
          <button
            onClick={handlePosting}
            disabled={posting || terposting}
            className="w-full rounded-xl bg-green-600 px-4 py-3 text-sm font-bold text-white transition hover:bg-green-500 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {terposting ? "✅ Sudah Terposting" : posting ? "⏳ Memposting..." : "📤 Posting Sekarang"}
          </button>
          <button
            onClick={handleBuang}
            disabled={membuang}
            className="w-full rounded-xl bg-red-600/90 px-4 py-3 text-sm font-bold text-white transition hover:bg-red-500 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {membuang ? "⏳ Membuang..." : "🗑️ Buang"}
          </button>
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div
          className={`fixed bottom-6 left-1/2 z-50 w-[92%] max-w-md -translate-x-1/2 rounded-2xl px-5 py-4 text-sm font-semibold shadow-2xl ring-1 ${
            toastError
              ? "bg-red-950 text-red-200 ring-red-500/40"
              : "bg-green-950 text-green-200 ring-green-500/40"
          }`}
        >
          {toast}
        </div>
      )}
    </article>
  );
}
