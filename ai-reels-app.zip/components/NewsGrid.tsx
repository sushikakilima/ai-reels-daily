"use client";

import { useState } from "react";
import NewsCard, { type NewsItem } from "./NewsCard";

export default function NewsGrid({
  initialItems,
  error,
}: {
  initialItems: NewsItem[];
  error: string | null;
}) {
  const [items, setItems] = useState<NewsItem[]>(initialItems);

  function handleHilang(id: string) {
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  if (error) {
    return (
      <div className="mx-auto max-w-xl rounded-2xl bg-card p-8 text-center ring-1 ring-red-500/30">
        <div className="text-5xl">⚠️</div>
        <h2 className="mt-4 text-lg font-bold text-red-300">
          Gagal memuat berita
        </h2>
        <p className="mt-2 text-sm text-slate-400">{error}</p>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-xl rounded-2xl bg-card p-10 text-center ring-1 ring-white/10">
        <div className="text-6xl">🌙</div>
        <h2 className="mt-4 text-lg font-bold">Belum ada berita hari ini</h2>
        <p className="mt-2 text-sm text-slate-400">
          Kurasi otomatis berjalan setiap jam 05:00 WIB. Kembali lagi nanti,
          atau jalankan cron manual untuk mengisi berita hari ini.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-4 md:gap-5 lg:grid-cols-5">
      {items.map((item) => (
        <NewsCard key={item.id} item={item} onHilang={handleHilang} />
      ))}
    </div>
  );
}
