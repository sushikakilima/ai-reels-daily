"use client";

import { useEffect, useState } from "react";

declare global {
  interface Window {
    FB?: {
      init: (params: Record<string, unknown>) => void;
      login: (
        cb: (res: { authResponse?: { code?: string }; status?: string }) => void,
        opts?: Record<string, unknown>
      ) => void;
    };
    fbAsyncInit?: () => void;
  }
}

export default function FbLoginButton({ appId }: { appId: string }) {
  const [siap, setSiap] = useState(false);

  useEffect(() => {
    window.fbAsyncInit = function () {
      window.FB?.init({
        appId,
        cookie: true,
        xfbml: false,
        version: "v21.0",
      });
      setSiap(true);
    };
    const script = document.createElement("script");
    script.src = "https://connect.facebook.net/id_ID/sdk.js";
    script.async = true;
    script.defer = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    };
  }, [appId]);

  function handleLogin() {
    window.FB?.login(
      (res) => {
        if (res.authResponse?.code) {
          // Tukarkan code lewat endpoint callback server
          window.location.href = `/api/auth/fb/callback?code=${encodeURIComponent(res.authResponse.code)}`;
        } else {
          alert("Login dibatalkan atau gagal. Coba lagi.");
        }
      },
      {
        scope: "instagram_basic,instagram_content_publish,pages_show_list",
        // Minta code (bukan token) agar bisa ditukar aman di server
        response_type: "code",
      } as Record<string, unknown>
    );
  }

  return (
    <button
      onClick={handleLogin}
      disabled={!siap}
      className="gradient-bg w-full rounded-2xl px-6 py-4 text-base font-bold text-white shadow-lg transition hover:opacity-90 disabled:opacity-50 sm:w-auto"
    >
      {siap ? "🔵 Login dengan Facebook" : "⏳ Memuat..."}
    </button>
  );
}
