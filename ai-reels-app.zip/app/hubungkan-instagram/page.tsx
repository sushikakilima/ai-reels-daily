import Link from "next/link";
import FbLoginButton from "@/components/FbLoginButton";

export const dynamic = "force-dynamic";

export default function HubungkanInstagram() {
  const appId = process.env.FB_APP_ID || "";
  const igTerhubung = !!process.env.IG_USER_ID && !!process.env.FB_PAGE_ACCESS_TOKEN;

  return (
    <main className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
      <Link href="/" className="text-sm text-violet-300 hover:underline">
        ← Kembali ke dashboard
      </Link>

      <h1 className="gradient-text mt-4 text-3xl font-extrabold sm:text-4xl">
        Hubungkan Instagram
      </h1>
      <p className="mt-2 text-sm text-slate-400">
        Agar tombol &quot;Posting Sekarang&quot; bisa memposting Reels ke akun
        Instagram Anda.
      </p>

      {igTerhubung ? (
        <div className="mt-6 rounded-2xl bg-green-950/60 p-5 ring-1 ring-green-500/40">
          <p className="font-bold text-green-300">
            ✅ Instagram sudah terhubung
          </p>
          <p className="mt-1 text-sm text-green-200/80">
            IG_USER_ID dan FB_PAGE_ACCESS_TOKEN sudah dikonfigurasi. Anda bisa
            memposting dari dashboard.
          </p>
        </div>
      ) : (
        <div className="mt-6 rounded-2xl bg-card p-5 ring-1 ring-white/10">
          <p className="font-bold text-amber-300">
            ⚠️ Instagram belum terhubung
          </p>
          <p className="mt-1 text-sm text-slate-400">
            Ikuti langkah di bawah sampai selesai, lalu kembali ke dashboard.
          </p>
        </div>
      )}

      {/* (a) Login dengan Facebook */}
      <section className="mt-8">
        <h2 className="text-xl font-bold">Cara cepat: login Facebook</h2>
        {appId ? (
          <div className="mt-4">
            <FbLoginButton appId={appId} />
            <p className="mt-3 text-xs text-slate-500">
              Izin yang diminta: instagram_basic, instagram_content_publish,
              pages_show_list.
            </p>
          </div>
        ) : (
          <div className="mt-4 rounded-2xl bg-card p-5 ring-1 ring-white/10">
            <p className="text-sm text-slate-300">
              Tombol login belum bisa tampil karena{" "}
              <b>FB_APP_ID</b> belum diatur di environment.
            </p>
            <p className="mt-2 text-sm text-slate-400">
              Buat aplikasi di{" "}
              <a
                href="https://developers.facebook.com/apps"
                target="_blank"
                rel="noopener noreferrer"
                className="text-sky-400 hover:underline"
              >
                developers.facebook.com/apps
              </a>
              , tambahkan produk &quot;Facebook Login&quot;, lalu isi
              FB_APP_ID &amp; FB_APP_SECRET di env Vercel.
            </p>
          </div>
        )}
      </section>

      {/* (b) Panduan manual */}
      <section className="mt-10">
        <h2 className="text-xl font-bold">Panduan manual langkah-demi-langkah</h2>
        <ol className="mt-4 space-y-4">
          {[
            {
              judul: "Login akun Facebook PRIBADI",
              isi: "Pastikan Anda login memakai akun Facebook pribadi Anda, BUKAN akun bisnis. Akun bisnis tidak bisa dipakai untuk login aplikasi.",
            },
            {
              judul: "Buat Facebook Page untuk usaha",
              isi: "Buat Halaman Facebook baru (mis. untuk usaha/konten Anda) dari akun pribadi tersebut. Anda harus menjadi admin Halaman ini.",
            },
            {
              judul: "Ubah Instagram ke Akun Bisnis & hubungkan ke Page",
              isi: "Di aplikasi Instagram @hendrawankuswanto: Pengaturan → Jenis akun → ubah ke Akun Bisnis/Creator. Lalu di Pengaturan → Pusat Akun, hubungkan Instagram tersebut ke Facebook Page yang dibuat di langkah 2.",
            },
            {
              judul: "Beri izin aplikasi",
              isi: "Saat login Facebook di atas (atau di pengaturan aplikasi), setujui permission: instagram_basic, instagram_content_publish, dan pages_show_list.",
            },
            {
              judul: "Salin ID & token ke env Vercel",
              isi: "Setelah login berhasil, halaman callback menampilkan IG User ID dan Page Access Token. Salin keduanya ke Environment Variables Vercel: IG_USER_ID dan FB_PAGE_ACCESS_TOKEN, lalu redeploy.",
            },
          ].map((s, i) => (
            <li
              key={i}
              className="rounded-2xl bg-card p-5 ring-1 ring-white/10"
            >
              <p className="font-bold text-violet-300">
                {i + 1}. {s.judul}
              </p>
              <p className="mt-1 text-sm text-slate-400">{s.isi}</p>
            </li>
          ))}
        </ol>
      </section>

      {/* (c) Peringatan masalah koneksi Meta */}
      <div className="mt-8 rounded-2xl bg-amber-950/60 p-5 ring-1 ring-amber-500/40">
        <p className="font-bold text-amber-300">⚠️ Perhatian: riwayat masalah koneksi</p>
        <p className="mt-2 text-sm text-amber-200/90">
          Diketahui ada masalah koneksi Meta pada akun ini (error 403
          &quot;User does not have a linked Facebook account&quot; pada
          2026-10-02). Jika login gagal, ulangi langkah 1–3 di atas dengan
          teliti (pastikan Instagram Bisnis benar-benar terhubung ke Halaman di
          Pusat Akun), lalu coba lagi.
        </p>
      </div>
    </main>
  );
}
