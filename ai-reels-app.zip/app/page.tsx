import { headers } from "next/headers";
import NewsGrid from "@/components/NewsGrid";
import { getMissingEnvKeys } from "@/lib/env-status";
import type { NewsItem } from "@/components/NewsCard";

export const dynamic = "force-dynamic";

function tanggalHariIni(): string {
  return new Intl.DateTimeFormat("id-ID", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "Asia/Jakarta",
  }).format(new Date());
}

async function ambilBerita(): Promise<{ items: NewsItem[]; error: string | null }> {
  try {
    const h = headers();
    const host = h.get("x-forwarded-host") || h.get("host") || "localhost:3000";
    const proto = h.get("x-forwarded-proto") || "http";
    const res = await fetch(`${proto}://${host}/api/news`, { cache: "no-store" });
    const data = await res.json();
    if (!res.ok || !data.sukses) {
      return { items: [], error: data.error || "Gagal memuat berita." };
    }
    return { items: data.data || [], error: null };
  } catch {
    return { items: [], error: "Tidak bisa terhubung ke server. Periksa koneksi lalu muat ulang." };
  }
}

export default async function Dashboard() {
  const { items, error } = await ambilBerita();
  const missing = getMissingEnvKeys();

  return (
    <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      {/* Header */}
      <header className="mb-8 text-center">
        <h1 className="gradient-text text-4xl font-extrabold tracking-tight sm:text-5xl">
          AI REELS DAILY
        </h1>
        <p className="mt-2 text-sm text-slate-400">
          Kurasi berita AI harian • Siap posting sebagai Reels
        </p>
        <p className="mt-1 text-sm font-semibold text-slate-300">
          📅 {tanggalHariIni()}
        </p>
        <div className="mt-4 flex justify-center gap-3">
          <a
            href="/hubungkan-instagram"
            className="rounded-xl bg-card px-5 py-2.5 text-sm font-bold text-violet-300 ring-1 ring-violet-500/40 transition hover:bg-card2"
          >
            🔗 Hubungkan Instagram
          </a>
        </div>
      </header>

      {/* Banner status env */}
      {missing.length > 0 && (
        <div className="mb-8 rounded-2xl bg-amber-950/60 p-5 ring-1 ring-amber-500/40">
          <h2 className="text-sm font-bold text-amber-300">
            ⚠️ Konfigurasi belum lengkap ({missing.length})
          </h2>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-amber-200/90">
            {missing.map((m) => (
              <li key={m.key}>
                <span className="font-semibold">{m.label}</span>
                <span className="text-amber-400/70"> — {m.key}</span>
                {m.wajib && (
                  <span className="ml-2 rounded-full bg-amber-500/20 px-2 py-0.5 text-xs font-bold text-amber-300">
                    wajib
                  </span>
                )}
              </li>
            ))}
          </ul>
          <p className="mt-3 text-xs text-amber-200/70">
            Tanpa kunci di atas, aplikasi berjalan dalam mode terbatas (berita
            tetap dikurasi dari RSS, konten & ilustrasi dibuat otomatis tanpa
            AI, posting Instagram nonaktif).
          </p>
        </div>
      )}

      {/* Grid berita */}
      <NewsGrid initialItems={items} error={error} />

      <footer className="mt-12 text-center text-xs text-slate-500">
        AI REELS DAILY • Kurasi otomatis 05:00 WIB • Posting hanya manual lewat
        tombol &quot;Posting Sekarang&quot;
      </footer>
    </main>
  );
}
