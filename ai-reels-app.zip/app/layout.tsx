import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AI REELS DAILY",
  description: "Kurasi berita AI harian siap posting sebagai Reels Instagram",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id">
      <body className="min-h-screen bg-ink text-slate-100 antialiased">
        {children}
      </body>
    </html>
  );
}
