import { NextRequest, NextResponse } from "next/server";
import { getSupabase } from "@/lib/supabase";

export async function POST(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const supabase = getSupabase();
    const { error } = await supabase
      .from("ai_news")
      .update({ status: "discarded" })
      .eq("id", params.id);

    if (error) throw error;

    return NextResponse.json({ sukses: true, pesan: "Berita dibuang." });
  } catch (e) {
    console.error("Gagal membuang berita:", e);
    return NextResponse.json(
      { sukses: false, error: "Gagal membuang berita. Coba lagi." },
      { status: 500 }
    );
  }
}
