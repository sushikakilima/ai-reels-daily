import { NextRequest, NextResponse } from "next/server";
import { getSupabase } from "@/lib/supabase";

const GRAPH = "https://graph.facebook.com/v21.0";

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

interface MediaContainer {
  id?: string;
  error?: { message?: string; code?: number };
}

interface ContainerStatus {
  status_code?: string;
  error?: { message?: string };
}

// Polling status container media sampai FINISHED (maks ~90 detik).
async function waitForFinished(
  creationId: string,
  accessToken: string
): Promise<{ ok: boolean; error?: string }> {
  const attempts = 18; // 18 x 5 detik = 90 detik
  for (let i = 0; i < attempts; i++) {
    await sleep(5000);
    try {
      const res = await fetch(
        `${GRAPH}/${creationId}?fields=status_code&access_token=${encodeURIComponent(accessToken)}`
      );
      const data = (await res.json()) as ContainerStatus;
      const code = data.status_code;
      if (code === "FINISHED") return { ok: true };
      if (code === "ERROR" || code === "EXPIRED") {
        return {
          ok: false,
          error: "Instagram gagal memproses media (status: " + code + ").",
        };
      }
    } catch {
      // coba lagi
    }
  }
  return { ok: false, error: "Waktu tunggu pemrosesan Instagram habis (90 detik)." };
}

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const igUserId = process.env.IG_USER_ID;
  const pageToken = process.env.FB_PAGE_ACCESS_TOKEN;

  if (!igUserId || !pageToken) {
    return NextResponse.json(
      {
        sukses: false,
        error: "Hubungkan akun Instagram dulu",
        connectUrl: "/hubungkan-instagram",
      },
      { status: 400 }
    );
  }

  try {
    const supabase = getSupabase();

    // Ambil data berita
    const { data: news, error: fetchError } = await supabase
      .from("ai_news")
      .select("id, caption_id, illustration_url, reels_video_url, status")
      .eq("id", params.id)
      .single();

    if (fetchError || !news) {
      return NextResponse.json(
        { sukses: false, error: "Berita tidak ditemukan." },
        { status: 404 }
      );
    }
    if (news.status === "posted") {
      return NextResponse.json(
        { sukses: false, error: "Berita ini sudah terposting." },
        { status: 400 }
      );
    }

    const hasVideo = !!news.reels_video_url;
    if (!hasVideo && !news.illustration_url) {
      return NextResponse.json(
        { sukses: false, error: "Tidak ada gambar/video untuk diposting." },
        { status: 400 }
      );
    }

    // 1. Buat media container
    const createBody: Record<string, string> = {
      caption: news.caption_id || "",
      access_token: pageToken,
    };
    if (hasVideo) {
      createBody.video_url = news.reels_video_url as string;
      createBody.media_type = "REELS";
    } else {
      createBody.image_url = news.illustration_url as string;
    }

    const createRes = await fetch(`${GRAPH}/${igUserId}/media`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(createBody),
    });
    const created = (await createRes.json()) as MediaContainer;
    if (!createRes.ok || !created.id) {
      const msg = created.error?.message || "Gagal membuat media di Instagram.";
      return NextResponse.json(
        { sukses: false, error: `Gagal membuat media Instagram: ${msg}` },
        { status: 502 }
      );
    }

    // 2. Tunggu sampai FINISHED
    const waited = await waitForFinished(created.id, pageToken);
    if (!waited.ok) {
      return NextResponse.json(
        { sukses: false, error: waited.error || "Pemrosesan media gagal." },
        { status: 502 }
      );
    }

    // 3. Publish
    const publishRes = await fetch(`${GRAPH}/${igUserId}/media_publish`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        creation_id: created.id,
        access_token: pageToken,
      }),
    });
    const published = (await publishRes.json()) as { id?: string; error?: { message?: string } };
    if (!publishRes.ok || !published.id) {
      const msg = published.error?.message || "Gagal mempublish media.";
      return NextResponse.json(
        { sukses: false, error: `Gagal mempublish ke Instagram: ${msg}` },
        { status: 502 }
      );
    }

    // 4. Update status
    try {
      await supabase
        .from("ai_news")
        .update({ status: "posted" })
        .eq("id", params.id);
    } catch {
      // posting sudah berhasil; kegagalan update status dicatat saja
    }

    return NextResponse.json({
      sukses: true,
      pesan: "Berhasil diposting ke Instagram Reels.",
      media_id: published.id,
    });
  } catch (e) {
    console.error("Gagal posting:", e);
    return NextResponse.json(
      { sukses: false, error: "Terjadi kesalahan saat memposting. Coba lagi." },
      { status: 500 }
    );
  }
}
