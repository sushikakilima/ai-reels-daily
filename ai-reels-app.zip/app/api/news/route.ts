import { NextResponse } from "next/server";
import { getSupabase } from "@/lib/supabase";

export const dynamic = "force-dynamic";

// Awal hari ini 00:00 WIB dalam format ISO (00:00 WIB = 17:00 UTC hari sebelumnya).
function startOfTodayWIB(): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Jakarta",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
  const [y, m, d] = parts.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d, -7, 0, 0)).toISOString();
}

export async function GET() {
  try {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from("ai_news")
      .select("*")
      .gte("created_at", startOfTodayWIB())
      .in("status", ["ready", "posted"])
      .order("published_at", { ascending: false });

    if (error) throw error;

    return NextResponse.json({ sukses: true, data: data || [] });
  } catch (e) {
    console.error("Gagal mengambil berita:", e);
    return NextResponse.json(
      {
        sukses: false,
        data: [],
        error:
          "Gagal mengambil data berita. Kemungkinan tabel 'ai_news' belum dibuat di Supabase. Jalankan cron harian dulu atau buat tabel sesuai skema.",
      },
      { status: 500 }
    );
  }
}
