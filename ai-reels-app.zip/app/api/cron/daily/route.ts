import { NextRequest, NextResponse } from "next/server";
import { fetchNewsLast24h } from "@/lib/pipeline/fetch";
import { dedupeNews } from "@/lib/pipeline/dedupe";
import { categorizeNews, selectWithCategoryVariety } from "@/lib/pipeline/categorize";
import { generateContent } from "@/lib/pipeline/generate";
import { buildAssets } from "@/lib/pipeline/assets";
import { getSupabase, isSupabaseConfigured } from "@/lib/supabase";

export const maxDuration = 60;
export const dynamic = "force-dynamic";

interface CronItem {
  judul: string;
  kategori: string;
  url: string;
  ilustrasi: string;
}

export async function GET(req: NextRequest) {
  // ---- Proteksi ----
  const expected = process.env.CRON_SECRET;
  if (!expected) {
    return NextResponse.json(
      { sukses: false, error: "CRON_SECRET belum dikonfigurasi di server." },
      { status: 500 }
    );
  }
  const authHeader = req.headers.get("authorization") || "";
  const querySecret = req.nextUrl.searchParams.get("secret") || "";
  if (authHeader !== `Bearer ${expected}` && querySecret !== expected) {
    return NextResponse.json(
      { sukses: false, error: "Tidak diizinkan: secret salah atau hilang." },
      { status: 401 }
    );
  }

  if (!isSupabaseConfigured()) {
    return NextResponse.json(
      { sukses: false, error: "Basis data Supabase belum dikonfigurasi." },
      { status: 500 }
    );
  }

  const supabase = getSupabase();
  const items: CronItem[] = [];
  const deadline = Date.now() + 480000; // budget total ~8 menit (terjemahan + ilustrasi AI gratis)

  try {
    // 1. Fetch berita 24 jam terakhir
    const fetched = await fetchNewsLast24h();

    // 2. Dedupe (2 lapis: URL + kemiripan judul)
    const unique = await dedupeNews(fetched);

    // 3. Kategorikan
    const categorized = unique.map((item) => ({
      ...item,
      category: categorizeNews(item.title, item.summary),
    }));

    // 4. Pilih 10 dengan variasi kategori
    const selected = selectWithCategoryVariety(categorized, 10, 3);

    // 5. Untuk tiap item: generate → aset → insert
    const today = new Date().toISOString().slice(0, 10).replace(/-/g, "");
    const runId = Date.now().toString(36); // nama file unik per run (hindari konflik upsert)
    let idx = 0;

    for (const item of selected) {
      if (Date.now() > deadline) break;
      idx++;
      try {
        // Cek duplikat antar-hari: original_url sudah ada?
        let alreadyExists = false;
        try {
          const { data } = await supabase
            .from("ai_news")
            .select("id")
            .eq("original_url", item.url)
            .limit(1);
          alreadyExists = !!data && data.length > 0;
        } catch {
          // tabel mungkin belum ada → lanjutkan
        }
        if (alreadyExists) continue;

        const content = await generateContent(item, item.category);
        const slug = `${today}-${runId}-${String(idx).padStart(2, "0")}`;
        const assets = await buildAssets(content.indonesian_title, slug, deadline, item.imageUrl, item.url);

        try {
          const { error } = await supabase.from("ai_news").insert({
            original_title: item.title,
            indonesian_title: content.indonesian_title,
            original_url: item.url,
            summary_id: content.summary_points.join("\n"),
            caption_id: content.caption,
            illustration_url: assets.illustrationUrl,
            reels_video_url: assets.videoUrl,
            category: content.category,
            published_at: item.publishedAt,
            status: "ready",
          });
          if (error) throw error;
        } catch (e) {
          console.error("Gagal insert:", e);
          continue;
        }

        items.push({ judul: content.indonesian_title, kategori: content.category, url: item.url, ilustrasi: assets.illustrationNote });
      } catch (e) {
        console.error("Gagal memproses item:", item.url, e);
        continue;
      }
    }

    return NextResponse.json({
      sukses: true,
      jumlah: items.length,
      items,
      catatan:
        "Konten TIDAK diposting otomatis. Posting hanya lewat tombol 'Posting Sekarang' di dashboard.",
    });
  } catch (e) {
    console.error("Cron gagal:", e);
    return NextResponse.json(
      { sukses: false, error: "Terjadi kesalahan saat menjalankan kurasi harian." },
      { status: 500 }
    );
  }
}
