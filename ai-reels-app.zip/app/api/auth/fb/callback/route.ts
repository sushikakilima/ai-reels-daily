import { NextRequest, NextResponse } from "next/server";

const GRAPH = "https://graph.facebook.com/v21.0";

interface TokenResponse {
  access_token?: string;
  error?: { message?: string };
}

interface AccountsResponse {
  data?: Array<{
    name?: string;
    access_token?: string;
    instagram_business_account?: { id?: string };
  }>;
  error?: { message?: string };
}

function htmlPage(
  title: string,
  bodyHtml: string,
  isError: boolean
): NextResponse {
  const color = isError ? "#f87171" : "#34d399";
  return new NextResponse(
    `<!DOCTYPE html>
<html lang="id">
<head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>${title}</title>
<style>
body{background:#0a0a0f;color:#e2e8f0;font-family:system-ui,sans-serif;max-width:720px;margin:0 auto;padding:32px 20px;line-height:1.6}
h1{color:${color}}pre{background:#14141d;border:1px solid #2a2a3a;border-radius:12px;padding:16px;overflow:auto;font-size:14px}
ol li{margin-bottom:8px}.warn{background:#451a03;border:1px solid #92400e;border-radius:12px;padding:12px 16px;margin-top:24px}
code{background:#1b1b28;padding:2px 6px;border-radius:6px}
a{color:#93c5fd}
</style></head>
<body>${bodyHtml}</body></html>`,
    { headers: { "Content-Type": "text/html; charset=utf-8" } }
  );
}

export async function GET(req: NextRequest) {
  const appId = process.env.FB_APP_ID;
  const appSecret = process.env.FB_APP_SECRET;

  if (!appId || !appSecret) {
    return htmlPage(
      "Konfigurasi Kurang",
      `<h1>Konfigurasi belum lengkap</h1><p>FB_APP_ID atau FB_APP_SECRET belum diatur di environment. Atur dulu di Vercel, lalu ulangi login.</p><p><a href="/hubungkan-instagram">← Kembali ke panduan</a></p>`,
      true
    );
  }

  const code = req.nextUrl.searchParams.get("code");
  const err = req.nextUrl.searchParams.get("error_description");
  if (!code) {
    return htmlPage(
      "Login Dibatalkan",
      `<h1>Login dibatalkan</h1><p>${err ? err : "Tidak ada kode otorisasi dari Facebook."}</p><p><a href="/hubungkan-instagram">← Coba lagi</a></p>`,
      true
    );
  }

  try {
    const redirectUri = `${req.nextUrl.origin}/api/auth/fb/callback`;

    // 1. Tukar code → short-lived access token
    const tokenRes = await fetch(
      `${GRAPH}/oauth/access_token?client_id=${encodeURIComponent(appId)}` +
        `&redirect_uri=${encodeURIComponent(redirectUri)}` +
        `&client_secret=${encodeURIComponent(appSecret)}` +
        `&code=${encodeURIComponent(code)}`
    );
    const tokenData = (await tokenRes.json()) as TokenResponse;
    if (!tokenRes.ok || !tokenData.access_token) {
      throw new Error(tokenData.error?.message || "Gagal menukar kode otorisasi.");
    }

    // 2. Tukar ke long-lived token
    const longRes = await fetch(
      `${GRAPH}/oauth/access_token?grant_type=fb_exchange_token` +
        `&client_id=${encodeURIComponent(appId)}` +
        `&client_secret=${encodeURIComponent(appSecret)}` +
        `&fb_exchange_token=${encodeURIComponent(tokenData.access_token)}`
    );
    const longData = (await longRes.json()) as TokenResponse;
    const longToken = longData.access_token || tokenData.access_token;

    // 3. Ambil daftar Page + akun Instagram bisnis yang terhubung
    const accRes = await fetch(
      `${GRAPH}/me/accounts?fields=name,access_token,instagram_business_account&access_token=${encodeURIComponent(longToken)}`
    );
    const accData = (await accRes.json()) as AccountsResponse;
    if (!accRes.ok) {
      throw new Error(accData.error?.message || "Gagal mengambil daftar Halaman.");
    }

    const page = (accData.data || []).find(
      (p) => p.instagram_business_account?.id
    );

    if (!page || !page.instagram_business_account?.id || !page.access_token) {
      return htmlPage(
        "Instagram Tidak Ditemukan",
        `<h1>Belum ada Instagram Bisnis terhubung</h1>
<p>Tidak ditemukan Halaman Facebook yang terhubung ke akun Instagram Bisnis/Creator.</p>
<ol>
<li>Pastikan akun Instagram <b>@hendrawankuswanto</b> sudah diubah ke Akun Bisnis/Creator.</li>
<li>Hubungkan Instagram tersebut ke Halaman Facebook di Pengaturan Instagram → Pusat Akun.</li>
<li>Ulangi login dari <a href="/hubungkan-instagram">halaman panduan</a>.</li>
</ol>`,
        true
      );
    }

    const result = {
      ig_user_id: page.instagram_business_account.id,
      page_access_token: page.access_token,
      page_name: page.name,
    };

    // Tampilkan JSON + instruksi simpan manual ke env Vercel.
    // Nilai TIDAK pernah disimpan otomatis ke mana pun.
    const body = `
<h1>✅ Berhasil terhubung!</h1>
<p>Akun Instagram Bisnis ditemukan di Halaman <b>${page.name || "(tanpa nama)"}</b>.</p>
<p>Salin nilai di bawah ini, lalu simpan <b>manual</b> sebagai Environment Variables di Vercel:</p>
<pre>${JSON.stringify(result, null, 2)}</pre>
<ol>
<li>Buka dashboard Vercel → proyek <b>ai-reels-daily</b> → <b>Settings → Environment Variables</b>.</li>
<li>Tambahkan <code>IG_USER_ID</code> dengan nilai <code>ig_user_id</code> di atas.</li>
<li>Tambahkan <code>FB_PAGE_ACCESS_TOKEN</code> dengan nilai <code>page_access_token</code> di atas.</li>
<li>Klik <b>Save</b>, lalu <b>Redeploy</b> agar nilai baru aktif.</li>
<li>Kembali ke <a href="/">dashboard</a> — tombol "Posting Sekarang" akan aktif.</li>
</ol>
<div class="warn">⚠️ Jangan bagikan <code>page_access_token</code> ke siapa pun. Token ini setara dengan kata sandi halaman Anda.</div>`;

    return htmlPage("Berhasil Terhubung", body, false);
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Terjadi kesalahan tak terduga.";
    return htmlPage(
      "Gagal Menghubungkan",
      `<h1>Gagal menghubungkan</h1><p>${msg}</p><p><a href="/hubungkan-instagram">← Coba lagi</a></p>`,
      true
    );
  }
}
