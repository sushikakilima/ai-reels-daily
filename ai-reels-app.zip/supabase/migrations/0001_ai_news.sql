-- ============================================================
-- Migrasi 0001: Skema database untuk proyek "AI REELS DAILY"
-- Project Supabase : komunitas-ai-klaten (region Singapore)
-- Catatan arsitektur: aplikasi hanya memakai ANON key (service_role
-- key tidak tersedia), jadi RLS dikonfigurasi agar anon key dapat
-- membaca seluruh berita, menulis berita baru lewat route cron yang
-- diproteksi CRON_SECRET, dan memperbarui status berita.
-- ============================================================

-- ----------------------------------------------------------------
-- Tabel: ai_news
-- Menyimpan berita AI harian beserta konten Indonesia (judul,
-- caption, ilustrasi, video reels) untuk pipeline AI Reels Daily.
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ai_news (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  original_title   text NOT NULL,          -- judul asli (bahasa sumber)
  indonesian_title text NOT NULL,          -- judul yang sudah diterjemahkan ke Bahasa Indonesia
  original_url     text NOT NULL UNIQUE,   -- tautan berita asli; unik agar tidak duplikat
  summary_id       text,                   -- ringkasan dalam Bahasa Indonesia
  caption_id       text,                   -- caption siap posting (Bahasa Indonesia)
  illustration_url text,                   -- URL gambar ilustrasi di bucket 'reels-assets'
  reels_video_url  text,                   -- URL video reels hasil generate
  category         text,                   -- kategori berita (mis. model, riset, produk)
  published_at     timestamptz,            -- waktu publikasi berita asli
  created_at       timestamptz DEFAULT now(), -- waktu baris dibuat di database
  status           text NOT NULL DEFAULT 'ready'
                   CHECK (status IN ('ready', 'posted', 'discarded'))
                   -- ready: siap diproses  | posted: sudah diposting
                   -- discarded: dibuang/tidak dipakai
);

-- ----------------------------------------------------------------
-- Index untuk performa query umum
-- ----------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_ai_news_published_at
  ON ai_news (published_at DESC);   -- urut berita terbaru dari sumber

CREATE INDEX IF NOT EXISTS idx_ai_news_status
  ON ai_news (status);              -- filter berdasarkan status

CREATE INDEX IF NOT EXISTS idx_ai_news_created_at
  ON ai_news (created_at DESC);     -- urut berita terbaru masuk ke database

-- ----------------------------------------------------------------
-- Row Level Security (RLS)
-- Wajib diaktifkan karena akses aplikasi hanya memakai ANON key.
-- ----------------------------------------------------------------
ALTER TABLE ai_news ENABLE ROW LEVEL SECURITY;

-- Kebijakan 1: semua orang (anon) boleh MEMBACA seluruh berita.
DROP POLICY IF EXISTS "Publik baca berita" ON ai_news;
CREATE POLICY "Publik baca berita"
  ON ai_news FOR SELECT
  USING (true);

-- Kebijakan 2: anon boleh MENAMBAH berita baru.
-- Aman karena route cron aplikasi diproteksi dengan CRON_SECRET,
-- sehingga hanya pemanggil cron resmi yang bisa menulis.
DROP POLICY IF EXISTS "Fungsi cron tulis berita" ON ai_news;
CREATE POLICY "Fungsi cron tulis berita"
  ON ai_news FOR INSERT
  WITH CHECK (true);

-- Kebijakan 3: anon boleh MENGUBAH berita, tetapi kolom status
-- hanya boleh berisi nilai yang valid ('ready','posted','discarded').
DROP POLICY IF EXISTS "Ubah status berita" ON ai_news;
CREATE POLICY "Ubah status berita"
  ON ai_news FOR UPDATE
  USING (true)
  WITH CHECK (status IN ('ready', 'posted', 'discarded'));

-- Catatan: tidak ada kebijakan DELETE untuk anon, sehingga baris
-- tidak bisa dihapus lewat anon key (hapus hanya lewat dashboard).

-- ----------------------------------------------------------------
-- Storage bucket: reels-assets (publik)
-- Menyimpan aset ilustrasi & video reels.
-- ----------------------------------------------------------------
INSERT INTO storage.buckets (id, name, public)
VALUES ('reels-assets', 'reels-assets', true)
ON CONFLICT (id) DO NOTHING;

-- Kebijakan 1: semua orang boleh MEMBACA file di bucket reels-assets.
DROP POLICY IF EXISTS "Publik baca aset reels" ON storage.objects;
CREATE POLICY "Publik baca aset reels"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'reels-assets');

-- Kebijakan 2: anon boleh MENGUNGGAH file ke bucket reels-assets.
-- Unggahan dilakukan lewat aplikasi (route cron dilindungi CRON_SECRET).
DROP POLICY IF EXISTS "Unggah aset reels" ON storage.objects;
CREATE POLICY "Unggah aset reels"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'reels-assets');

-- Catatan: tidak ada kebijakan DELETE pada storage.objects,
-- sehingga file tidak bisa dihapus lewat anon key.

-- ============================================================
-- Verifikasi cepat setelah Run (opsional, jalankan manual):
--   SELECT count(*) FROM ai_news;                     -- harus 0 / tanpa error
--   SELECT id, name, public FROM storage.buckets
--     WHERE id = 'reels-assets';                      -- public = true
-- ============================================================
